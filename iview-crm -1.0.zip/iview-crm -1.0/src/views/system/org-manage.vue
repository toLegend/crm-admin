<style lang="less">
    @import './user-manage.less';
</style>

<template>
    <div>
        <Row>
            <Col span="6">
                <Card>
                    <Tree :data="orgTree" :render="renderContent" @on-select-change="treeClick"></Tree>
                </Card>
            </Col>
            <Col span="18" class="padding-left-10">
                <Card>
                    <can-edit-table class="margin-top-10" refs="table" @changePage="changePage"
                                    :highlight-row="true" v-model="editInlineAndCellData" @on-modal-edit="show" @on-delete="remove"
                                    :columns-list="showUserColumns" :total="total" :current="current" :page-size="pageSize"></can-edit-table>
                </Card>
            </Col>
        </Row>
        <Modal :width="900" v-model="showUserModal" @on-ok="userSave" :styles="{top: '10px'}">
            <ownspace_index :user-id="userId" ref="ownspace_index" :transfer="transfer" @handle-search="handleSearch"></ownspace_index>
        </Modal>
        <Modal :width="900" v-model="showOrgModal" @on-ok="orgSave" :styles="{top: '10px'}" :loading="modalLoading">
            <div>
                <Card>
                    <p slot="title">
                        <Icon type="person"></Icon>
                        机构/部门信息
                    </p>
                    <div>
                        <Form
                                ref="orgForm"
                                :model="orgForm"
                                :label-width="100"
                                label-position="right"
                                :rules="inforValidate"
                        >
                            <FormItem label="角色姓名：" prop="name">
                                <div style="display:inline-block;width:300px;">
                                    <Input v-model="orgForm.name" ></Input>
                                </div>
                            </FormItem>
                            <FormItem label="是否可用：">
                                <Checkbox v-model="orgForm.available"></Checkbox>
                            </FormItem>
                        </Form>
                    </div>
                </Card>
            </div>
        </Modal>
    </div>
</template>

<script>
    import canEditTable from '../tables/components/canEditTable.vue';
    import tableData from '../tables/components/table_data.js';
    import ownspace_index from '../own-space/own-space.vue';
export default {
    name: 'user-manage',
    components: {
        canEditTable,
        ownspace_index
    },
    data () {
        return {
            showUserColumns: tableData.showUserColumns,
            editInlineAndCellData: [],
            searchConName: '',
            total: 0,
            current: 1,
            pageSize: 6,
            orgTree: [],
            showUserModal: false,
            showOrgModal: false,
            transfer: false,
            userId: 0,
            orgForm: {},
            orgId: null,
            inforValidate: {
                name: [
                    { required: true, message: '请输入机构名称', trigger: 'blur' }
                ]
            },
            modalLoading: true
        };
    },
    methods: {
        handleSearch(pageNum) {
            this.util.ajax.post("/sys/user/api/findPageUsers",{pageNum:pageNum,pageSize:this.pageSize,value:this.searchConName,orgId:this.orgId}).then(response => {
                this.total = response.data.data.total;
                this.editInlineAndCellData = response.data.data.list;
            });
        },
        changeSearch(){
            this.handleSearch(1);
        },
        changePage (pageNum) {
            this.handleSearch(pageNum);
        },
        treeClick(data) {
            console.log(data);
        },
        renderContent (h, { root, node, data }) {
            return h('span', {
                style: {
                    display: 'inline-block',
                    width: '100%'
                }
            }, [
                h('span', [
                    h('Icon', {
                        props: {
                            type: 'ios-paper-outline'
                        },
                        style: {
                            marginRight: '8px'
                        }
                    }),
                    h('span',{
                        class: 'ivu-tree-title',
                        on: {
                            click: () => {
                                this.orgId = data.id;
                                this.handleSearch(1);
                            }
                        }
                    },data.title)
                ]),
                h('span', {
                    style: {
                        display: 'inline-block',
                        float: 'right',
                        marginRight: '10px'
                    }
                }, [
                    h('Button', {
                        props:{
                            icon: 'edit',
                            type: 'primary',
                            size: 'small'
                        },
                        style: {
                            marginRight: '8px'
                        },
                        on: {
                            click: () => {
                                //编辑机构
                                this.util.ajax.get("/sys/org/api/findById/"+data.id).then(response => {
                                    this.orgForm = response.data.data;
                                    this.showOrgModal = true;
                                });
                            }
                        }
                    }),
                    h('Button', {
                        props:{
                            icon: 'plus',
                            type: 'primary',
                            size: 'small'
                        },
                        on: {
                            click: () => {
                                //新增机构
                                this.orgForm = {};
                                this.orgForm.available = true;
                                this.orgForm.pid = data.id;
                                this.showOrgModal = true;
                            }
                        }
                    })
                ])
            ]);
        },
        show (val, index) {
            this.userId = val.id;
            this.showUserModal = true;
            this.$refs.ownspace_index.init(this.userId);
        },
        remove (val, index) {
            this.$Notice.info({title: '提示', desc: "该用户不能删除"});
        },
        userSave(){
            //保存用户
            this.$refs.ownspace_index.saveEdit();
        },
        orgSave(){
            this.util.ajax.post("/sys/org/api/saveOrg",this.orgForm).then(response => {
                if(response.data.code === 200){
                    this.$Message.success(response.data.data);
                    this.getOrgTree();
                    this.showOrgModal = false;
                 }
                this.modalLoading = false;
                this.$nextTick(() => {
                    this.modalLoading = true;
                });

            });
        },
        getOrgTree(){
            this.util.ajax.get("/sys/org/api/treeOrg").then(response => {
                this.orgTree = response.data.data;
            });
        }
    },
    computed: {
    },
    created () {
        this.handleSearch(1);
        this.getOrgTree();
    }
};
</script>
