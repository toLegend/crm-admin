<style lang="less">
    @import './user-manage.less';
</style>

<template>
    <div>
        <Input v-model="searchConName" icon="search" @on-change="changeSearch" placeholder="请输入名称搜索..."
               style="width: 200px"/>
        <can-edit-table class="margin-top-10" refs="table" @clickUp="clickUp" @dblclickUp="dblclickUp"
                        :highlight-row="true" v-model="editInlineAndCellData" @on-modal-edit="show" @on-modal-add="add"
                        :columns-list="showUserColumns" :total="total" :current="current" :page-size="pageSize"></can-edit-table>
        <Modal :width="900" v-model="showFormModal" @on-ok="ok" :styles="{top: '10px'}" :loading="modalLoading">
            <div>
                <Card>
                    <p slot="title">
                        <Icon type="person"></Icon>
                        角色信息
                    </p>
                    <div>
                        <Form
                                ref="roleForm"
                                :model="roleForm"
                                :label-width="100"
                                label-position="right"
                                :rules="inforValidate"
                        >
                            <FormItem label="角色姓名：" prop="name">
                                <div style="display:inline-block;width:300px;">
                                    <Input v-model="roleForm.name" ></Input>
                                </div>
                            </FormItem>
                            <FormItem label="角色标识：">
                                <div style="display:inline-block;width:300px;">
                                    <Input v-model="roleForm.role" ></Input>
                                </div>
                            </FormItem>
                            <FormItem label="是否可用：">
                                <Checkbox v-model="roleForm.available"></Checkbox>
                            </FormItem>
                        </Form>
                    </div>
                </Card>
            </div>
        </Modal>
    </div>
</template>

<script>
    import canEditTable from '../tables/components/canEditTable.vue';
    import tableData from '../tables/components/table_data.js';
export default {
    name: 'user-manage',
    components: {
        canEditTable
    },
    data () {
        return {
            showUserColumns: tableData.viewRoleColumns,
            editInlineAndCellData: [],
            searchConName: '',
            total: 0,
            current: 1,
            pageSize: 5,
            roleForm:{},
            showFormModal: false,
            inforValidate: {
                name: [
                    { required: true, message: '请输入角色名称', trigger: 'blur' }
                ]
            },
            modalLoading: true
        };
    },
    methods: {
        handleSearch(pageNum) {
            this.util.ajax.post("/sys/role/api/findPageRoles",{pageNum:pageNum,pageSize:10,value:this.searchConName}).then(response => {
                this.total = response.data.data.total;
                this.editInlineAndCellData = response.data.data.list;
            })
        },
        changeSearch(){
            this.handleSearch(1);
        },
        changePage (pageNum) {
            this.handleSearch(pageNum);
        },
        clickUp(data) {

        },
        dblclickUp(data) {

        },
        show (val, index) {
            this.util.ajax.get("/sys/role/api/findRoleById/"+val.id).then(response => {
                if(response.data.code === 200){
                    this.showFormModal = true;
                    this.roleForm = response.data.data;
                }else{
                    this.$Notice.error({title: '提示', desc: response.data.message})
                }
            });
        },
        add (val, index) {
            this.roleForm = {};
            this.roleForm.available = true;
            this.showFormModal = true;
        },
        ok(){
            this.$refs['roleForm'].validate((valid) => {
                if (valid) {
                    this.util.ajax.post("/sys/role/api/saveRole",this.roleForm).then(response => {
                        if(response.data.code === 200){
                            this.$Message.success('保存成功');
                            this.showFormModal = false;
                            this.handleSearch(1);
                        }else{
                            this.$Message.error('保存异常');
                        }
                    });
                }
                this.modalLoading = false;
                this.$nextTick(() => {
                    this.modalLoading = true;
                });
            });
        }
    },
    computed: {

    },
    created () {
        this.handleSearch(1);
    }
};
</script>
