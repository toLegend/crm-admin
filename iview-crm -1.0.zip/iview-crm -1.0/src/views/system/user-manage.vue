<style lang="less">
    @import './user-manage.less';
</style>

<template>
    <div>
        <Input v-model="searchConName" icon="search" @on-change="changeSearch" placeholder="请输入名称搜索..."
               style="width: 200px"/>
        <can-edit-table class="margin-top-10" refs="table" @clickUp="clickUp" @dblclickUp="dblclickUp" @changePage="changePage"
                        :highlight-row="true" v-model="editInlineAndCellData" @on-modal-edit="show" @on-delete="remove"
                        :columns-list="showUserColumns" :total="total" :current="current" :page-size="pageSize"></can-edit-table>
        <Modal :width="900" v-model="showCurrentTableData" @on-ok="ok" :styles="{top: '10px'}">
             <ownspace_index :user-id="userId" ref="ownspace_index" :transfer="transfer" @handle-search="handleSearch"></ownspace_index>
        </Modal>
    </div>
</template>

<script>
    import canEditTable from '../tables/components/canEditTable.vue';
    import tableData from '../tables/components/table_data.js';
    import ownspace_index from '../own-space/own-space.vue';
export default {
    name: 'user-manage',
    components: {
        canEditTable,
        ownspace_index
    },
    data () {
        return {
            showUserColumns: tableData.showUserColumns,
            editInlineAndCellData: [],
            searchConName: '',
            total: 0,
            current: 1,
            pageSize: 5,
            showCurrentTableData: false,
            userId: 0,
            transfer: false
        };
    },
    methods: {
        handleSearch(pageNum) {
            this.util.ajax.post("/sys/user/api/findPageUsers",{pageNum:pageNum,pageSize:this.pageSize,value:this.searchConName}).then(response => {
                this.total = response.data.data.total;
                this.editInlineAndCellData = response.data.data.list;
            })
        },
        changeSearch(){
            this.handleSearch(1);
        },
        changePage (pageNum) {
            this.handleSearch(pageNum);
        },
        clickUp(data) {
            //单击行 to do
        },
        dblclickUp(data) {
            //双击行 to do
        },
        show (val, index) {
            this.userId = val.id;
            this.showCurrentTableData = true;
            this.$refs.ownspace_index.init(this.userId);
        },
        remove (val, index) {
            this.$Notice.info({title: '提示', desc: "该用户不能删除"});
        },
        ok(){
            this.$refs.ownspace_index.saveEdit();
        }
    },
    computed: {

    },
    created () {
        this.handleSearch(1);
    }
};
</script>
