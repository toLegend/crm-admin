<style lang="less">
    @import '../../styles/common.less';
    @import './access.less';
</style>

<template>
    <div class="access">
        <Row>
            <Col span="8">
                <Card>
                     <p slot="title">
                         <Icon type="android-contact"></Icon>
                         当前用户:
                     </p>
                    <Button type="primary" class="access-user-button" @click="savePermission" :disabled="saveDisable">{{this.$t('save')}}</Button>
                    <div class="access-user-con access-current-user-con">
                        <img :src="avatorPath" alt="">
                        <p>当前用户角色:<b></b></p>
                        <Row>
                            <Input v-model="role" icon="search" @on-focus="selectRole" style="width: 200px"/>
                        </Row>
                    </div>
                </Card>
            </Col>
            <Col span="16" class="padding-left-10">
                <Card>
                    <p slot="title">
                        <Icon type="android-contacts"></Icon>
                        不同权限用户的不同菜单
                    </p>
                    <CheckboxGroup v-model="fruit" @on-change="checkboxGroupChange">
                        <Tree :data="menuList" :render="renderContent"></Tree>
                    </CheckboxGroup>
                </Card>
            </Col>
        </Row>
        <Modal :width="900" v-model="showCurrentTableData">
            <Input v-model="searchConName" icon="search" @on-change="changeSearch" placeholder="请输入名称搜索..."
                   style="width: 200px"/>
            <can-edit-table class="margin-top-10" refs="table" @clickUp="clickUp" @dblclickUp="dblclickUp" @changePage="changePage"
                            :highlight-row="true" v-model="editInlineAndCellData"
                            :columns-list="showRoleColumns" :total="total" :current="current" :page-size="pageSize"></can-edit-table>
        </Modal>
    </div>
</template>

<script>
    import Cookies from 'js-cookie';
    import canEditTable from '../tables/components/canEditTable.vue';
    import tableData from '../tables/components/table_data.js';

    export default {
        name: 'access_index',
        components: {
            canEditTable
        },
        data() {
            return {
                role: "",
                roleId:"",
                searchConName: "",
                editInlineAndCellData: [],
                showRoleColumns: [],
                showCurrentTableData: false,
                fruit: [],
                saveDisable: true,
                total: 0,
                current: 1,
                pageSize: 5
            }
        },
        computed: {
            avatorPath() {
                return localStorage.avatorImgPath;
            },
            menuList () {
                for(let item of this.$store.state.app.appMenuList){
                    item.title = this.itemTitle(item);
                    if(item.children){
                        for(let childItem of item.children){
                            childItem.title = this.itemTitle(childItem);
                        }
                    }
                }
                return this.$store.state.app.appMenuList;
            }
        },
        methods: {
            //查询角色
            handleSearch(pageNum) {
                this.util.ajax.post("/sys/role/api/findPageRoles",{pageNum:pageNum,pageSize:this.pageSize,value:this.searchConName}).then(response => {
                    this.total = response.data.data.total;
                    this.editInlineAndCellData = response.data.data.list;
                })
            },
            getData() {
                this.showRoleColumns = tableData.showRoleColumns;
                //角色列表
                this.handleSearch(1);
            },
            changeAccess(res) {
                if (res) {
                    this.accessCode = 1;
                    Cookies.set('access', 1);
                } else {
                    this.accessCode = 0;
                    Cookies.set('access', 0);
                }
                this.$store.commit('updateMenulist');
            },
            filterMethod(value, option) {
                return option.label.toUpperCase().indexOf(value.toUpperCase()) !== -1;
            },
            changeSearch(){
                this.handleSearch(1);
            },
            changePage (pageNum) {
                this.handleSearch(pageNum);
            },
            selectRole() {
                this.showCurrentTableData = true;
            },
            findPermissions(roleId){
                this.util.ajax.get("/sys/role/api/permissions/"+roleId).then(response => {
                    this.fruit = response.data;
                })
            },
            clickUp(data) {
                this.role = data.name;
                this.roleId = data.id;
                this.findPermissions(data.id)
            },
            dblclickUp(data) {
                this.role = data.name;
                this.roleId = data.id;
                this.showCurrentTableData = false;
                this.findPermissions(data.id)
            },
            renderContent (h, { root, node, data }) {
                return h('span', {
                    style: {
                        display: 'inline-block',
                        width: '100%'
                    }
                }, [
                    h('span', [
                        h('Icon', {
                            props: {
                                type: 'ios-paper-outline'
                            },
                            style: {
                                marginRight: '8px'
                            }
                        }),
                        h('span', data.title)
                    ]),
                    h('span', {
                        style: {
                            display: 'inline-block',
                            float: 'right',
                            marginRight: '32px'
                        }
                    }, [
                        h('Checkbox', {
                            props:{
                                label:data.access,
                            }
                        },'查看'),
                        h('Checkbox', {
                            props:{
                                label:data.access.split(':')[0]+':add',
                            }
                        },'新增'),
                        h('Checkbox', {
                            props:{
                                label:data.access.split(':')[0]+':update',
                            }
                        },'修改'),
                        h('Checkbox', {
                            props:{
                                label:data.access.split(':')[0]+':del',
                            }
                        },'删除')
                    ])
                ]);
            },
            itemTitle (item) {
                if (typeof item.title === 'object') {
                    return this.$t(item.title.i18n);
                } else {
                    return item.title;
                }
            },
            checkboxGroupChange(){
                if(this.role === ""){
                    this.fruit = [];
                    this.$Notice.warning({title: '提示', desc: '请选择角色'});
                }else{
                    this.saveDisable = false;
                }
            },
            savePermission(){
                this.util.ajax.post("/sys/role/api/savePermission",{roleId:this.roleId,permission:this.fruit}).then(response => {
                    this.$Notice.info({title: '保存', desc: response.data.message});
                    //设置保存按钮禁用
                    this.saveDisable = true;
                    Cookies.set("access",response.data.data);
                    this.$store.commit('updateMenulist');
                });
            }
        },
        created() {
            this.getData();
        },
    };
</script>

<style>

</style>
