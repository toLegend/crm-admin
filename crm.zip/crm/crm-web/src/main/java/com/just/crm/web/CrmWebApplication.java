package com.just.crm.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 * @author MOMF
 * @date 2018-03-20
 */
@SpringBootApplication
@ComponentScan("com.just.crm")
@EnableJpaRepositories("com.just.crm.dao.jpainterface")
@EntityScan("com.just.crm.entity")
public class CrmWebApplication extends SpringBootServletInitializer {

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(CrmWebApplication.class);
    }

    public static void main(String[] args) {
        SpringApplication.run(CrmWebApplication.class, args);
    }
}
