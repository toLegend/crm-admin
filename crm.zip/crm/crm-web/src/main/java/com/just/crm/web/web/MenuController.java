package com.just.crm.web.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author MOMF
 * @date 2018-03-29
 */
@Controller
@RequestMapping("/sys/menu/web")
public class MenuController {
    /**
     * 跳转菜单管理界面
     * @return
     */
    @GetMapping("/view")
      public String view(){
          return "menu";
      }
}
