package com.just.crm.web.app;

import com.just.crm.entity.Menu;
import com.just.crm.entity.dto.MenuResponse;
import com.just.crm.service.MenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author MOMF
 * @date 2018-03-30
 */
@RestController
@RequestMapping("/sys/menu/api")
public class MenuRestController {

    @Autowired
    MenuService menuService;
    /**
     * 查询用户授权菜单
     * @return
     */
    @GetMapping("/findMenus")
    public List<MenuResponse> findMenus(){
        return menuService.findMenus();
    }

    /**
     * 菜单新增
     * @param menu 新增的菜单信息
     * @return
     */
    @RequestMapping("/save")
    public String save(@RequestBody Menu menu){
        menuService.save(menu);
        return "保存成功";
    }

    @RequestMapping("/delete/{id}")
    public String delete(@PathVariable Long id){
        menuService.delete(id);
        return "删除成功";
    }
}
