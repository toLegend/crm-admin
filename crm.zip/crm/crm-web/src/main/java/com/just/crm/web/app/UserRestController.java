package com.just.crm.web.app;

import com.just.crm.entity.User;
import com.just.crm.entity.dto.UserRequest;
import com.just.crm.service.RoleService;
import com.just.crm.service.UserService;
import com.just.crm.service.util.CurrentUtil;
import com.just.crm.web.util.Result;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @author MOMF
 * @date 2018-03-19
 */
@RestController
@RequestMapping("/sys/user/api")
public class UserRestController {

    @Autowired
    UserService userService;

    @Autowired
    CurrentUtil currentUtil;

    @Autowired
    RoleService roleService;

    /**
     *  根据用户姓名查询用户信息
     * @param name 用户姓名
     * @return
     */
    @GetMapping("/find/{name}")
    @RequiresPermissions("user:view")
    public User findUser(@PathVariable String name){
        return userService.findByName(name);
    }

    /**
     * 根据用户信息更新或新增实体记录
     * @param userRequest 用户信息
     * @return
     */
    @PostMapping("/saveUser")
    public Result saveUser(@RequestBody UserRequest userRequest){
        try{

            userService.saveUser(userRequest,roleService.findRoles(userRequest.getId()));
            return Result.success("保存成功");
        }catch (Exception e){
            return Result.error(e.getMessage());
        }

    }

    /**
     * 查询用户列表
     * @return
     */
    @PostMapping("/findPageUsers")
    public Result findPageUsers(@RequestBody UserRequest userRequest){
        return Result.success(userService.findPageUsers(userRequest));
    }

    /**
     * 个人中心信息
     */
    @GetMapping("/owne/{id}")
    public Result owne(@PathVariable Long id){
        if(id == null || id == 0){
            return Result.success(currentUtil.getCurrentUser());
        }
        return Result.success(userService.findById(id));
    }
}
