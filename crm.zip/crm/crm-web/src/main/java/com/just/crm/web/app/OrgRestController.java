package com.just.crm.web.app;

import com.just.crm.entity.Organization;
import com.just.crm.service.OrgService;
import com.just.crm.service.UserService;
import com.just.crm.web.util.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @author MOMF
 * @date 2018-03-19
 */
@RestController
@RequestMapping("/sys/org/api")
public class OrgRestController {

    @Autowired
    OrgService orgService;

    @Autowired
    UserService userService;

    /**
     *  机构树查询
     * @return
     */
    @GetMapping("/treeOrg")
    public Result treeOrg(){return Result.success(orgService.treeOrg());}

    /**
     * 根据ID查询机构信息
     * @param id
     * @retun
     */
    @GetMapping("/findById/{id}")
    public Result findById(@PathVariable Long id){
        return Result.success(orgService.findById(id));
    }

    /**
     * 保存/更新机构
     * @param organization
     * @return
     */
    @PostMapping("/saveOrg")
    public Result saveOrg(@RequestBody Organization organization){
        orgService.saveOrg(organization);
        return Result.success("保存成功");
    }


}
