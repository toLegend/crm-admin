package com.just.crm.web.web;

import com.just.crm.entity.User;
import com.just.crm.service.UserService;
import com.just.crm.service.util.CurrentUtil;
import com.just.crm.service.util.RedisUtil;
import com.just.crm.web.util.Result;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.*;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import java.util.HashMap;
import java.util.Map;

/**
 * @author MOMF
 * @date 2018-03-24
 */
@Controller
public class LoginController {

    @Autowired
    RedisUtil redisUtil;

    @Autowired
    CurrentUtil currentUtil;

    @Autowired
    UserService userService;

    /**
     * 登录页面跳转
     * @return
     */
    @GetMapping("/index")
    public String index(){
        return"index";
    }

    /**
     * 登录页面跳转
     * @return
     */
    @GetMapping("/login")
    @ResponseBody
    public String login(){
        return "login";
    }

    /**
     * ajax请求登录认证
     * @param user
     * @return
     */
    @PostMapping("/ajaxLogin")
    @ResponseBody
    public Result ajaxLogin(@RequestBody User user){
        // 登录失败从request中获取shiro处理的异常信息。
        Subject subject = SecurityUtils.getSubject();
        UsernamePasswordToken token = new UsernamePasswordToken(user.getUsername(), user.getPassword());
        String msg = "";
        Map<String,Object> map = new HashMap(16);
        try {
            subject.login(token);
            map.put("token", subject.getSession().getId());
            //查询用户菜单权限
            map.put("access",userService.permissions(currentUtil.getCurrentUser().getId()));
        } catch (IncorrectCredentialsException e) {
            return Result.error("密码错误");
        } catch (LockedAccountException e) {
            return Result.error("登录失败，该用户已被冻结");
        } catch (AuthenticationException e) {
            return Result.error("该用户不存在");
        } catch (Exception e) {
            e.printStackTrace();
        }
        // 此方法不处理登录成功,由前端vue进行处理
        return Result.success(map);
    }
}
