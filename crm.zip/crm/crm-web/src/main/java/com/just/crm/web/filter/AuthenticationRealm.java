package com.just.crm.web.filter;

import com.just.crm.entity.Role;
import com.just.crm.entity.User;
import com.just.crm.service.RoleService;
import com.just.crm.service.UserService;
import com.just.crm.service.util.RedisUtil;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authc.credential.CredentialsMatcher;
import org.apache.shiro.authc.credential.HashedCredentialsMatcher;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.SimplePrincipalCollection;
import org.apache.shiro.util.ByteSource;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author MOMF
 * @date 2018-03-24
 */
public class AuthenticationRealm extends AuthorizingRealm {

    @Autowired
    UserService userService;

    @Autowired
    RoleService roleService;

    @Autowired
    RedisUtil redisUtil;

    /**
     * 获取用户权限
     * @param principalCollection
     * @return
     */
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        SimpleAuthorizationInfo authorizationInfo = new SimpleAuthorizationInfo();
        User userInfo  = (User) principalCollection.getPrimaryPrincipal();
        for(Role role:roleService.findRoles(userInfo.getId())){
            authorizationInfo.addRole(role.getRole());
        }
        //缓存到redis
        authorizationInfo.addStringPermissions(userService.permissions(userInfo.getId()));
        return authorizationInfo;
    }

    /**
     * 登录认证
     * @param authenticationToken
     * @return
     * @throws AuthenticationException
     */
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken) throws AuthenticationException {
        //获取用户的输入的账号.
        String userName = (String)authenticationToken.getPrincipal();
        System.out.println(authenticationToken.getCredentials());
        //通过username从数据库中查找 User对象，如果找到，没找到.
        //实际项目中，这里可以根据实际情况做缓存，如果不做，Shiro自己也是有时间间隔机制，2分钟内不会重复执行该方法
        User user = userService.findByName(userName);
        if(user == null){
            return null;
        }
        //获取用户盐值
        ByteSource salt = ByteSource.Util.bytes(userName+user.getSalt());
        //用户名、密码、salt、realm name （String passw = new SimpleHash("md5", "123456",userName+user.getSalt(), 2).toHex()）
        SimpleAuthenticationInfo authenticationInfo = new SimpleAuthenticationInfo(user,user.getPassword(),salt,getName());
        return authenticationInfo;
    }

    /**
     * 设置认证加密方式
     */
    @Override
    public void setCredentialsMatcher(CredentialsMatcher credentialsMatcher) {
        HashedCredentialsMatcher md5CredentialsMatcher = new HashedCredentialsMatcher();
        md5CredentialsMatcher.setHashAlgorithmName("md5");
        md5CredentialsMatcher.setHashIterations(2);
        md5CredentialsMatcher.setStoredCredentialsHexEncoded(true);
        super.setCredentialsMatcher(md5CredentialsMatcher);
    }

    /**
     * 清空用户权限缓存
     *
     * @param username
     */
    public void removeUserAuthorizationInfoCache(String username) {
        SimplePrincipalCollection pc = new SimplePrincipalCollection();
        pc.add(username, super.getName());
        super.clearCachedAuthorizationInfo(pc);
    }
}
