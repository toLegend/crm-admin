package com.just.crm.web.filter;

import com.jagregory.shiro.freemarker.ShiroTags;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;

import javax.annotation.PostConstruct;

/**
 * @author MOMF
 * @date 2018-03-27
 */
@Component
class ShiroTagsFreeMarkerCfg {
    @Autowired
    private FreeMarkerConfigurer freeMarkerConfigurer;

    /**
     * 定义freemarkermo shiro标签模板标签
     */
    @PostConstruct
    public void setSharedVariable(){
        freeMarkerConfigurer.getConfiguration().setSharedVariable("shiro", new ShiroTags());
    }
}
