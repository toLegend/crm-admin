package com.just.crm.web.app;
import com.just.crm.entity.Permission;
import com.just.crm.entity.Role;
import com.just.crm.entity.dto.PermissionRequest;
import com.just.crm.entity.dto.RoleRequest;
import com.just.crm.service.RoleService;
import com.just.crm.service.UserService;
import com.just.crm.service.util.CurrentUtil;
import com.just.crm.web.util.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @author MOMF
 * @date 2018-05-03
 */
@RestController
@RequestMapping("/sys/role/api")
public class RoleRestController {

    @Autowired
    private RoleService roleService;

    @Autowired
    private UserService userService;

    @Autowired
    CurrentUtil currentUtil;

    /**
     * 获取角色权限列表
     */
    @GetMapping("/permissions/{id}")
    public List<String> findPermissions(@PathVariable Long id){
        List<String> permissions = new ArrayList<>();
        for(Permission permission : roleService.findPermissions(id)){
            permissions.add(permission.getPermission());
        }
        return permissions;
   }

    /**
     * 保存角色权限列表
     * @param permissionRequest 权限列表
     */
    @PostMapping("/savePermission")
    public Result savePermission(@RequestBody PermissionRequest permissionRequest){
        roleService.savePermission(permissionRequest,roleService.findPermissions(permissionRequest.getRoleId()));
        return Result.success(userService.permissions(currentUtil.getCurrentUserId()));
    }

    /**
     * 根据ID查询角色
     */
    @GetMapping("/findRoleById/{id}")
    public Result findRoleById(@PathVariable Long id){
        return Result.success(roleService.findRoleById(id));
    }

    /**
     * 保存角色信息
     * @return
     */
    @PostMapping("/saveRole")
    public Result saveRole(@RequestBody Role role){
        return Result.success(roleService.saveRole(role));
    }

    /**
     * 获取用户角色列表（分页）
     * @param roleRequest
     * @return
     */
    @PostMapping("/findPageRoles")
    public Result findPageRoles(@RequestBody RoleRequest roleRequest){
        return Result.success(roleService.findPageRoles(roleRequest));
    }

    /**
     * 查询所有可用角色信息
     * @return Result
     */
    @GetMapping("/findAll")
    public Result findAll(){
        return Result.success(roleService.findAll());
    }

    /**
     * 查询用户角色
     * @param userId 用户ID
     * @return
     */
    @GetMapping("/findRoles/{userId}")
    public Result findRoles(@PathVariable Long userId){
        return Result.success(roleService.findRoles(userId));
    }
}
