package com.just.crm.service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.just.crm.dao.mapper.RoleMapper;
import com.just.crm.dao.mapper.UserMapper;
import com.just.crm.entity.Permission;
import com.just.crm.entity.Role;
import com.just.crm.entity.User;
import com.just.crm.dao.jpainterface.IUserDao;
import com.just.crm.entity.dto.UserRequest;
import com.just.crm.service.util.CacheConst;
import com.just.crm.service.util.CurrentUtil;
import com.just.crm.service.util.RedisUtil;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * @author MOMF
 * @date 2018-03-19
 */
@Service
@CacheConfig(cacheNames = "userCache")
public class UserService {

    @Autowired
    UserMapper userMapper;

    @Autowired
    RoleMapper roleMapper;

    @Autowired
    IUserDao iUserDao;

    @Autowired
    RedisUtil redisUtil;

    @Autowired
    RoleService roleService;

    @Autowired
    CurrentUtil currentUtil;

    /**
     *根据用户登录账号查询用户信息
     * @param name 用户姓名
     * @return
     */
    @Cacheable
    public User findByName(String name){
        System.out.println("findUser没有加载缓存");
        return userMapper.findByName(name);
    }

    /**
     * 根据ID查询用户信息
     * @param id 用户id
     * @return
     */
    public User findById(Long id){
        return  iUserDao.findById(id).get();
    }

    /**
     * 新增或更新用户信息
     * @param userRequest
     * @param userRoles 缓存的用户角色
     */
    @CacheEvict(cacheNames = "roleCache", key = "'com.just.crm.service.RoleService.findRoles_'+#userRequest.id")
    public void saveUser(UserRequest userRequest,List<Role> userRoles){
        userRequest.setUserId(userRequest.getId());
        User user = new User();
        BeanUtils.copyProperties(userRequest,user);
        iUserDao.save(user);

        //对比角色列表删除不包含部分
        List<String> delRoles = new ArrayList<>();
        for (Role role:userRoles){
            boolean exists = false;
            for(String userRole:userRequest.getUserRoles()){
                if(userRole.equals(role.getRole())){
                    exists = true;
                    break;
                }
            }
            if(!exists){
                delRoles.add(role.getRole());
            }
        }
        if(delRoles.size() > 0){
            UserRequest delRequest = new UserRequest();
            delRequest.setUserId(userRequest.getId());
            delRequest.setUserRoles(delRoles);
            userMapper.deleteUserRoles(delRequest);
        }
        //保存用户角色对照关系
        userMapper.saveUserRoles(userRequest);

    }


    /**
     * 查询用户列表（分页）
     */
    public PageInfo<User> findPageUsers(UserRequest userRequest) {
        PageHelper.startPage(userRequest.getPageNum(),userRequest.getPageSize());
        PageInfo<User> pageInfo = new PageInfo(userMapper.findAll(userRequest));
        return pageInfo;
    }

    /**
     * 获取用户权限列表
     */
    public Set<String> permissions(Long userId){
        Set<String> permissions = (Set<String>)redisUtil.get(CacheConst.permissionKey(userId));
        if(permissions == null){
            permissions = new HashSet<>();
            for(Role role:roleService.findRoles(userId)){
                for(Permission p:roleService.findPermissions(role.getId())){
                    permissions.add(p.getPermission());
                }
            }
            //缓存权限列表到redis
            redisUtil.set(CacheConst.permissionKey(userId),permissions,CacheConst.SMS_TEMPLATE_EXPIRE);
        }
        return permissions;
    }
}
