package com.just.crm.service;

import com.just.crm.dao.jpainterface.IOrganizationDao;
import com.just.crm.dao.mapper.OrgMapper;
import com.just.crm.entity.Organization;
import com.just.crm.entity.dto.OrgResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author MOMF
 * @date 2018-03-19
 */
@Service
@CacheConfig(cacheNames = "orgCache")
public class OrgService {

    @Autowired
    OrgMapper orgMapper;

    @Autowired
    IOrganizationDao iOrganizationDao;

    /**
     * 机构树查询
     * @return
     */
    public List<OrgResponse> treeOrg() {
        List<OrgResponse> organizations = orgMapper.treeOrg();
        List<OrgResponse> orgResponses = new ArrayList<>();
        for(OrgResponse organization : organizations){
            for(OrgResponse sunOrganization : organizations){
                if(organization.getId().equals(sunOrganization.getPid())){
                    organization.getChildren().add(sunOrganization);
                }
            }
            if(organization.getPid() == null || organization.getPid().equals(0L)){
                orgResponses.add(organization);
            }
        }
        return orgResponses;
    }

    /**
     * 根据ID查询机构
     * @param id
     * @return
     */
    public Organization findById(Long id) {
        return iOrganizationDao.findById(id).get();
    }

    /**
     * 保存/更新机构
     * @param organization
     */
    public void saveOrg(Organization organization) {
        iOrganizationDao.save(organization);
    }
}
