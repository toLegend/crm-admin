package com.just.crm.service.util;

import com.just.crm.entity.User;
import org.apache.shiro.SecurityUtils;
import org.springframework.stereotype.Component;

/**
 * @author MOMF
 * @date 2018-03-30
 */
@Component
public class CurrentUtil {
    /**
     * 获取登录用户
     * @return user
     */
    public User getCurrentUser(){
        return (User)SecurityUtils.getSubject().getPrincipal();
    }

    /**
     * 获取登录用户Id
     * @return userId
     */
    public Long getCurrentUserId(){
        return getCurrentUser().getId();
    }
}
