package com.just.crm.service.util;

/**
 * 定义 cache 的 key 和 expire time。
 *
 * @author LIUWEI22
 * @date 2015-10-12
 */
public class CacheConst {
    /**
     * cache key 前缀
     */
    static String prefix = "crm";

    /**
     * 缓存时间，秒
     */
    public static Long SMS_TEMPLATE_EXPIRE = 120 * 60L;

    /**
     * 缓存用户信息
     */
    public static String userKey(String name) {
        return prefix + ".userName." + name ;
    }

    /**
     * 缓存用户权限信息
     */
    public static String permissionKey(Long userId) {
        return prefix + ".permission."+userId ;
    }

}
