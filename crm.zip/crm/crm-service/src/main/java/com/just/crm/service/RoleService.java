package com.just.crm.service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.just.crm.dao.jpainterface.IRoleDao;
import com.just.crm.dao.mapper.PermissionMapper;
import com.just.crm.dao.mapper.RoleMapper;
import com.just.crm.entity.Permission;
import com.just.crm.entity.Role;
import com.just.crm.entity.UserRole;
import com.just.crm.entity.dto.PermissionRequest;
import com.just.crm.entity.dto.RoleRequest;
import com.just.crm.service.util.CacheConst;
import com.just.crm.service.util.RedisUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author MOMF
 * @date 2018-03-24
 */
@Service
@CacheConfig(cacheNames = "roleCache")
public class RoleService {

    @Autowired
    private PermissionMapper permissionMapper;

    @Autowired
    RedisUtil redisUtil;

    @Autowired
    RoleMapper roleMapper;

    @Autowired
    IRoleDao iRoleDao;

    /**
     * 根据角色ID获取权限列表
     * @param roleId 角色ID
     * @return
     */
    @Cacheable
    public List<Permission> findPermissions(Long roleId) {
        return permissionMapper.findPermissions(roleId);
    }

    /**
     * 保存角色权限
     * @param permissionRequest 权限列表
     * @param permissions 原来的权限列表
     * 删除角色对应权限列表缓存
     */
    @CacheEvict(key = "'com.just.crm.service.RoleService::findPermissions:' + #permissionRequest.getRoleId()")
    public void savePermission(PermissionRequest permissionRequest,List<Permission> permissions) {
        //对比权限列表删除不包含部分
        List<String> delPermission = new ArrayList<>();
        for (Permission oldPermission:permissions){
            boolean exists = false;
            for(String permission:permissionRequest.getPermission()){
                if(permission.equals(oldPermission.getPermission())){
                    exists = true;
                    break;
                }
            }
            if(!exists){
                delPermission.add(oldPermission.getPermission());
            }
        }
        if(delPermission.size() > 0){
            PermissionRequest delRequest = new PermissionRequest();
            delRequest.setPermission(delPermission);
            delRequest.setRoleId(permissionRequest.getRoleId());
            roleMapper.deletePermissions(delRequest);
        }
        roleMapper.savePermission(permissionRequest);
        //删除对应角色关联的用户权限缓存
        List<UserRole> userRoles = findUserRole(permissionRequest.getRoleId());
        for(UserRole userRole : userRoles){
            redisUtil.remove(CacheConst.permissionKey(userRole.getUserId()));
        }
    }

    /**
     * 查询所有关联用户
     * @param roleId 角色ID
     */
    public List<UserRole> findUserRole(Long roleId){
        return roleMapper.findUserRole(roleId);
    }

    /**
     * 根据ID查询角色信息
     * @param roleId 角色ID
     */
    public Role findRoleById(Long roleId){
        return iRoleDao.findById(roleId).get();
    }

    /**
     * 更新或保存角色
     * @param role
     * @return
     */
    @CacheEvict(key = "'com.just.crm.service.RoleService.findAll'")
    public Object saveRole(Role role) {
        return iRoleDao.save(role);
    }

    /**
     * 根据用户ID获取用户角色(分页查询)
     * @param roleRequest
     */
    public PageInfo<Role> findPageRoles(RoleRequest roleRequest) {
        PageHelper.startPage(roleRequest.getPageNum(),roleRequest.getPageSize());
        PageInfo<Role> pageInfo = new PageInfo(roleMapper.findPageRoles(roleRequest));
        return pageInfo;
    }

    /**
     * 根据用户ID获取用户角色
     */
    @Cacheable(key = "'com.just.crm.service.RoleService.findRoles_'+#userId")
    public List<Role> findRoles(Long userId) {
        return roleMapper.findRoles(userId);
    }

    /**
     * 查询所有可用角色信息
     * @return
     */
    @Cacheable(key = "'com.just.crm.service.RoleService.findAll'")
    public List<Role> findAll() {
        return roleMapper.findAll();
    }
}
