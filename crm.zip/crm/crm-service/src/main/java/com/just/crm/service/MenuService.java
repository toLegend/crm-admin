package com.just.crm.service;

import antlr.StringUtils;
import com.github.pagehelper.util.StringUtil;
import com.just.crm.dao.jpainterface.IMenuDao;
import com.just.crm.dao.mapper.MenuMapper;
import com.just.crm.entity.Menu;
import com.just.crm.entity.dto.MenuResponse;
import com.just.crm.service.util.CurrentUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author MOMF
 * @date 2018-03-30
 */
@Service
@CacheConfig(cacheNames = "MenuCache")
public class MenuService {

    @Autowired
    CurrentUtil currentUtil;
    @Autowired
    MenuMapper menuMapper;
    @Autowired
    IMenuDao iMenuDao;
    /**
     * 根据登录用户获取，权限菜单
     * @return
     */
    public List<MenuResponse> findMenus() {
      return menuMapper.findMenus(currentUtil.getCurrentUser().getId());
    }

    /**
     * 保存菜单信息
     * @param menu
     */
    public void save(Menu menu) {
        iMenuDao.save(menu);
    }

    /**
     * 删除菜单信息
     * @param id
     */
    public void delete(Long id) {
        iMenuDao.deleteById(id);
    }
}
