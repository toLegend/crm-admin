package com.just.crm.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

/**
 * @author MOMF
 * @date 2018-03-24
 */
@Setter
@Getter
@Entity
@Table(name="t_role_permission")
public class RolePermission {
    /**
     * ID
     */
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;
    /**
     * 角色ID
     */
    private Long roleId;
    /**
     * 权限ID
     */
    private Long permissionId;
}
