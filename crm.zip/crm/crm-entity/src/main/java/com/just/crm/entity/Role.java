package com.just.crm.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

/**
 * @author MOMF
 * @date 2018-03-24
 */
@Setter
@Getter
@Entity
@Table(name="t_role")
public class Role implements Serializable {
    /**
     * ID
     */
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;
    /**
     * 角色名称
     */
    private String name;
    /**
     * 角色标识
     */
    private String role;

    /**
     * 是否可用
     */
    private Boolean available = Boolean.TRUE;
}
