package com.just.crm.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

/**
 * @author MOMF
 * @date 2018-03-24
 */
@Setter
@Getter
@Entity
@Table(name="t_user_role")
public class UserRole {
    /**
     * ID
     */
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;
    /**
     * 角色ID
     */
    private Long roleId;
    /**
     * 用户ID
     */
    private Long userId;
}
