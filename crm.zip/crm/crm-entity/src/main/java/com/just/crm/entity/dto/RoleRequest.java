package com.just.crm.entity.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author MOMF
 * @date 2018-03-21
 */
@Getter
@Setter
@ToString
public class RoleRequest {
    /**
     * 第几页
     */
    private int pageNum;
    /**
     * 每页记录数
     */
    private int pageSize;
    /**
     * 过滤条件
     */
    private String value;

    /**
     * 用户ID
     */
    private Long userId;
}
