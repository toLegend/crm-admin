package com.just.crm.entity.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * @author MOMF
 * @date 2018-03-21
 */
@Getter
@Setter
@ToString
public class PermissionRequest {
    /**
     * 角色
     */
    private Long roleId;
    /**
     * 权限列表
     */
    private List<String> permission;
}
