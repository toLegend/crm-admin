package com.just.crm.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

/**
 * @author MOMF
 * @date 2018-03-29
 */
@Setter
@Getter
@Entity
@Table(name="t_ent")
public class Ent {
    /**
     * ID
     */
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;

    /**
     * 账套名称
     */
    private String name;

    /**
     * 是否可用
     */
    private Boolean available = Boolean.TRUE;

}
