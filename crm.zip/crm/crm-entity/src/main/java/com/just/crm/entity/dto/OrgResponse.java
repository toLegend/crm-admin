package com.just.crm.entity.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * @author MOMF
 * @date 2018-03-29
 */
@Setter
@Getter
public class OrgResponse {
    /**
     * ID
     */
    private Long id;

    /**
     * 父节点ID
     */
    private Long pid;

    /**
     * 机构名称
     */
    private String title;

    /**
     * 机构名称
     */
    private String name;

    /**
     * 是否可用
     */
    private Boolean available = Boolean.TRUE;

    /**
     * 子部门
     */
    private List<OrgResponse> children = new ArrayList<>();
}
