package com.just.crm.entity.dto;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.List;

/**
 * @author MOMF
 * @date 2018-03-30
 */
@Getter
@Setter
public class MenuResponse {
    /**
     * ID
     */
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;

    /**
     * 父节点ID
     */
    private Long pid;

    /**
     * 菜单名称
     */
    private String name;

    /**
     * 菜单URL
     */
    private String url;

    /**
     * 菜单图标
     */
    private String icon;

    /**
     * 是否可用
     */
    private Boolean available = Boolean.TRUE;

    /**
     * 用户ID
     */
    private String userId;

    /**
     * 直接点集合
     */
    private List<MenuResponse> menuResponses;
}
