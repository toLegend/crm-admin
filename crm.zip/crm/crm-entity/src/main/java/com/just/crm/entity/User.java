package com.just.crm.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

/**
 * @author MOMF
 * @date 2018-03-19
 */
@Setter
@Getter
@Entity
@Table(name="t_user")
public class User implements Serializable {

    /**
     * ID
     */
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;
    /**
     * 登录账号
     */
    private String username;
    /**
     * 用户姓名
     */
    private String name;
    /**
     * 用户年龄
     */
    private int age;
    /**
     * 登录密码
     */
    private String password;
    /**
     * 加密盐
     */
    private String salt;
    /**
     * 用户状态,create:创建未认证（比如没有激活，没有输入验证码等等）--等待验证的用户 , normal:正常状态,lock：用户被锁定.
     */
    private String state;

    /**
     * 是否可用
     */
    private Boolean available = Boolean.TRUE;

    /**
     * 手机号码
     */
    private String cellphone;

    /**
     * 所属机构
     */
    private Long orgId;

    /**
     * 账套ID
     */
    private Long entId;
}
