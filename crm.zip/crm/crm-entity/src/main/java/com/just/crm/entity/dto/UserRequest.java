package com.just.crm.entity.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * @author MOMF
 * @date 2018-03-21
 */
@Getter
@Setter
@ToString
public class UserRequest {
    /**
     * 第几页
     */
    private int pageNum;
    /**
     * 每页记录数
     */
    private int pageSize;
    /**
     * 过滤条件
     */
    private String value;
    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 用户ID 与实体一致
     */
    private Long id;
    /**
     * 登录账号
     */
    private String username;
    /**
     * 用户姓名
     */
    private String name;
    /**
     * 用户年龄
     */
    private int age;
    /**
     * 登录密码
     */
    private String password;
    /**
     * 加密盐
     */
    private String salt;
    /**
     * 用户状态,create:创建未认证（比如没有激活，没有输入验证码等等）--等待验证的用户 , normal:正常状态,lock：用户被锁定.
     */
    private String state;

    /**
     * 是否可用
     */
    private Boolean available = Boolean.TRUE;

    /**
     * 手机号码
     */
    private String cellphone;

    /**
     * 所属机构
     */
    private Long orgId;

    /**
     * 账套ID
     */
    private Long entId;

    /**
     * 用户角色列表
     */
    private List<String> userRoles;
}
