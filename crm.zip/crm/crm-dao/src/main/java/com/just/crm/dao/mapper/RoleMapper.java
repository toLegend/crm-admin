package com.just.crm.dao.mapper;

import com.just.crm.entity.Role;
import com.just.crm.entity.UserRole;
import com.just.crm.entity.dto.PermissionRequest;
import com.just.crm.entity.dto.RoleRequest;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

/**
 * @author MOMF
 * @date 2018-03-26
 */
@Mapper
public interface RoleMapper {

    /**
     * 根据用户查询角色
     * @param userId 用户ID
     * @return
     */
    List<Role> findRoles(Long userId);

    /**
     * 新增角色权限
     * @param permissionRequest
     */
    void savePermission(PermissionRequest permissionRequest);

    /**
     * 查询所有关联用户
     * @param roleId
     * @return
     */
    List<UserRole> findUserRole(Long roleId);

    /**
     * 删除角色权限
     * @param request 删除的权限列表
     */
    void deletePermissions(PermissionRequest request);

    /**
     * 根据用户查询角色
     * @param roleRequest 用户ID及条件
     * @return
     */
    List<Role> findPageRoles(RoleRequest roleRequest);

    /**
     * 查询所有可用角色信息
     * @return
     */
    List<Role> findAll();
}
