package com.just.crm.dao.mapper;

import com.just.crm.entity.dto.OrgResponse;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author MOMF
 * @date 2018-03-26
 */
@Mapper
public interface OrgMapper {

    /**
     * 机构树查询
     * @return
     */
    List<OrgResponse> treeOrg();
}
