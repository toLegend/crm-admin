package com.just.crm.dao.mapper;

import com.just.crm.entity.User;
import com.just.crm.entity.dto.UserRequest;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author MOMF
 * @date 2018-03-19
 */
@Mapper
public interface UserMapper {

    /**根据用户登录账号查询用户信息
     * @param name 用户名称
     * @return
     */
    User findByName (@Param("name")String name);

    /**
     * 新增用户信息
     * @param user
     */
    void saveUser (User user);

    /**
     * 查询用户列表
     * @return
     */
    List<User> findAll(UserRequest userRequest);

    /**
     * 新增/更新用户角色
     * @param userRequest
     */
    void saveUserRoles(UserRequest userRequest);

    /**
     * 删除角色权限
     * @param delRequest
     */
    void deleteUserRoles(UserRequest delRequest);
}
