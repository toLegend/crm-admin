package com.just.crm.dao.mapper;

import com.just.crm.entity.Permission;
import com.just.crm.entity.Role;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author MOMF
 * @date 2018-03-26
 */
@Mapper
public interface PermissionMapper {

    /**
     * 根据角色查询权限
     * @param roleId 角色ID
     * @return
     */
    List<Permission> findPermissions(Long roleId);
}
