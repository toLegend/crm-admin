package com.just.crm.dao.jpainterface;

import com.just.crm.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * 集成JPA接口
 * @author MOMF
 * @date 2018-03-20
 */
public interface IRoleDao extends JpaRepository<Role,Long> {

}
