package com.just.crm.dao.mapper;

import com.just.crm.entity.dto.MenuResponse;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author MOMF
 * @date 2018-03-26
 */
@Mapper
public interface MenuMapper {

    /**
     * 根据登录用户获取，权限菜单
     * @param userId
     * @return
     */
    List<MenuResponse> findMenus(Long userId);
}
