package com.just.crm.dao.jpainterface;

import com.just.crm.entity.Menu;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * 集成JPA接口
 * @author MOMF
 * @date 2018-04-02
 */
public interface IMenuDao extends JpaRepository<Menu,Long> {

}
