package com.just.crm.dao.config;

import org.mybatis.spring.annotation.MapperScan;
import org.mybatis.spring.mapper.MapperScannerConfigurer;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.context.annotation.Configuration;

/**
 * @author MOMF
 * @date 2018-03-20
 */
@Configuration
@MapperScan("com.just.crm.dao.mapper")
@AutoConfigureAfter(MyBatisConfig.class)
public class MyBatisMapperScannerConfig {
    private static final String TYPE_ALIASES_PACKAGE = "com.just.crm.dao.mapper";
    public MapperScannerConfigurer mapperScannerConfigurer(){
        MapperScannerConfigurer mapperScannerConfigurer = new MapperScannerConfigurer();
        mapperScannerConfigurer.setSqlSessionFactoryBeanName("sqlSessionFactory");
        mapperScannerConfigurer.setBasePackage(TYPE_ALIASES_PACKAGE);
        return mapperScannerConfigurer;
    }
}
