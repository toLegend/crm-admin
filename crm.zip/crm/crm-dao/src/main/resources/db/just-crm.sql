/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50720
Source Host           : localhost:3306
Source Database       : just-crm

Target Server Type    : MYSQL
Target Server Version : 50720
File Encoding         : 65001

Date: 2018-03-29 18:27:10
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for t_ent
-- ----------------------------
DROP TABLE IF EXISTS `t_ent`;
CREATE TABLE `t_ent` (
  `id` bigint(32) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_bin NOT NULL COMMENT '账套名称',
  `available` bit(1) DEFAULT NULL COMMENT '是否可用',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='账套信息表';

-- ----------------------------
-- Records of t_ent
-- ----------------------------

-- ----------------------------
-- Table structure for t_menu
-- ----------------------------
DROP TABLE IF EXISTS `t_menu`;
CREATE TABLE `t_menu` (
  `id` bigint(32) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_bin NOT NULL COMMENT '菜单名称',
  `url` varchar(64) COLLATE utf8_bin DEFAULT NULL COMMENT '菜单路径',
  `icon` varchar(32) COLLATE utf8_bin DEFAULT NULL COMMENT '菜单图标',
  `available` bit(1) DEFAULT NULL COMMENT '是否可用',
  `pid` bigint(32) DEFAULT NULL COMMENT '父节点ID',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='菜单信息表';

-- ----------------------------
-- Records of t_menu
-- ----------------------------
INSERT INTO `t_menu` VALUES ('1', '系统设置', '', 'flaticon-settings', '', null);
INSERT INTO `t_menu` VALUES ('2', '菜单管理', '/sys/menu/web/view', 'flaticon-computer', '', '1');

-- ----------------------------
-- Table structure for t_permission
-- ----------------------------
DROP TABLE IF EXISTS `t_permission`;
CREATE TABLE `t_permission` (
  `id` bigint(32) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_bin NOT NULL COMMENT '名称',
  `resource_type` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '资源类型',
  `url` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT '资源路径',
  `permission` varchar(1000) COLLATE utf8_bin DEFAULT NULL COMMENT '权限字符串',
  `parent_id` bigint(32) DEFAULT NULL COMMENT '父编号',
  `parent_ids` varchar(1000) COLLATE utf8_bin DEFAULT NULL COMMENT '父编号列表',
  `available` bit(1) DEFAULT NULL COMMENT '是否可用',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='用户角色关联表';

-- ----------------------------
-- Records of t_permission
-- ----------------------------
INSERT INTO `t_permission` VALUES ('1', '用户管理', 'menu', 'user/findAll', 'user:view', '0', '0/', '');
INSERT INTO `t_permission` VALUES ('2', '用户添加', 'button', 'user/save', 'user:add', '1', '0/1', '');
INSERT INTO `t_permission` VALUES ('3', '用户删除', 'button', 'user/delete', 'user:del', '1', '0/1', '');

-- ----------------------------
-- Table structure for t_role
-- ----------------------------
DROP TABLE IF EXISTS `t_role`;
CREATE TABLE `t_role` (
  `id` bigint(32) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_bin NOT NULL COMMENT '角色名称',
  `role` varchar(32) COLLATE utf8_bin DEFAULT NULL COMMENT '角色标识',
  `available` bit(1) DEFAULT NULL COMMENT '是否可用',
  `ent` bigint(32) DEFAULT NULL COMMENT '账套id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='角色信息表';

-- ----------------------------
-- Records of t_role
-- ----------------------------
INSERT INTO `t_role` VALUES ('1', '管理员', 'admin', '', null);
INSERT INTO `t_role` VALUES ('2', 'VIP会员', 'vip', '', null);
INSERT INTO `t_role` VALUES ('3', 'test', 'test', '', null);

-- ----------------------------
-- Table structure for t_role_menu
-- ----------------------------
DROP TABLE IF EXISTS `t_role_menu`;
CREATE TABLE `t_role_menu` (
  `id` bigint(32) NOT NULL AUTO_INCREMENT,
  `role_id` bigint(32) NOT NULL COMMENT '角色ID',
  `menu_id` varchar(64) COLLATE utf8_bin DEFAULT NULL COMMENT '菜单ID',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='角色菜单权限表';

-- ----------------------------
-- Records of t_role_menu
-- ----------------------------

-- ----------------------------
-- Table structure for t_role_permission
-- ----------------------------
DROP TABLE IF EXISTS `t_role_permission`;
CREATE TABLE `t_role_permission` (
  `id` bigint(32) NOT NULL AUTO_INCREMENT,
  `role_id` bigint(32) NOT NULL COMMENT '角色',
  `permission_id` bigint(32) DEFAULT NULL COMMENT '权限',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='角色权限关系表';

-- ----------------------------
-- Records of t_role_permission
-- ----------------------------
INSERT INTO `t_role_permission` VALUES ('10', '1', '1');
INSERT INTO `t_role_permission` VALUES ('11', '1', '2');
INSERT INTO `t_role_permission` VALUES ('12', '2', '3');

-- ----------------------------
-- Table structure for t_user
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user` (
  `id` bigint(32) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_bin NOT NULL,
  `username` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `age` int(5) DEFAULT NULL,
  `password` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT '密码',
  `salt` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT '加密密码的盐',
  `state` int(11) DEFAULT NULL COMMENT '用户状态,0:创建未认证（比如没有激活，没有输入验证码等等）--等待验证的用户 , 1:正常状态,2：用户被锁定.',
  `available` bit(1) DEFAULT NULL COMMENT '是否可用',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='用户信息表';

-- ----------------------------
-- Records of t_user
-- ----------------------------
INSERT INTO `t_user` VALUES ('10', 'mominfu', 'spring', '18', null, null, null, '');
INSERT INTO `t_user` VALUES ('2', 'peizhen', 'JUSTYOU', '15', null, null, null, '');
INSERT INTO `t_user` VALUES ('3', 'mmf', 'JUSTYOU', '16', null, null, null, '');
INSERT INTO `t_user` VALUES ('4', 'JUSTMYSQLF', 'JUSTME', '16', null, null, null, '');
INSERT INTO `t_user` VALUES ('5', 'JUSTDOIT', 'JUSTSOSO', '17', null, null, null, '');
INSERT INTO `t_user` VALUES ('7', 'JUSTNOW', 'to-do-some-thing', '19', null, null, null, '');
INSERT INTO `t_user` VALUES ('8', 'JUSTOUT', 'to-do-some-thing', '20', null, null, null, '');
INSERT INTO `t_user` VALUES ('9', 'JUSTSOMETIME', null, '20', null, null, null, '');
INSERT INTO `t_user` VALUES ('1', '管理员', 'admin', null, '4861e54146c3fee8dc1edb10ec98a97b', '202cb962ac59075b964b07152d234b70', '0', '');

-- ----------------------------
-- Table structure for t_user_role
-- ----------------------------
DROP TABLE IF EXISTS `t_user_role`;
CREATE TABLE `t_user_role` (
  `id` bigint(32) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(32) NOT NULL COMMENT '用户',
  `role_id` bigint(32) DEFAULT NULL COMMENT '角色',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='用户角色关联表';

-- ----------------------------
-- Records of t_user_role
-- ----------------------------
INSERT INTO `t_user_role` VALUES ('10', '1', '1');
